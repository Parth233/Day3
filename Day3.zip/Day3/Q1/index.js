function captianAmerica() {
const captianAmeric = document.getElementById("image")  
captianAmeric.src = 'https://hips.hearstapps.com/esq.h-cdn.co/assets/16/19/1280x640/landscape-1462802920-captain-america-civil-war-reviewed-by-a-10-year-old-kid.jpg?resize=1200:*'

}

function IronMan() {
    const IronMan1 = document.getElementById("image")  
    IronMan1.src = "https://wegotthiscovered.com/wp-content/uploads/2019/04/iron-man-avengers.jpg"
}

function Thor() {
    const Thor1 = document.getElementById("image")  
    Thor1.src = 'http://www.100hdwallpapers.com/wallpapers/2560x1600/thor_avengers-widescreen_wallpapers.jpg'
    
}

    