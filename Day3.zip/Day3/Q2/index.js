function change() {
    const change = document.getElementById("inpt1");
    document.getElementById("inpt2").value = change.value
}