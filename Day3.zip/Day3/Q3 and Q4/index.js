document.getElementById('write').innerText = 'Check Console'

let arr = [{
    name : "Parth",
    age : 21,
    country : 'India',
    hobbies : ['Surfing Web' , 'Football' , 'Writing' , 'Shayari']
} ,
{
    name:'Ankit',
    age : 55,
    country : 'Australia',
    hobbies : ['Indoor Games' , 'Reading']
} ,
{
    name : 'Jay',
    age : 20,
    country :'Canada',
    hobbies : ['Sleeping', 'Reading']
}
]

function DisplayAll(){
    for (let i = 0; i < arr.length; i++) {
        console.log('Object ' + i)
        console.log(arr[i].name)
        console.log(arr[i].country)
        console.log(arr[i].age)
        arr[i].hobbies.forEach(function (hobbie){
         console.log(hobbie)

        })
        console.log("")
        console.log("")
    }

}


DisplayAll()

let A = () => {
    console.log("Age Less Than 30")
    console.log("")
    for (let j = 0; j < arr.length; j++) {
        if (arr[j].age < 30) {
                console.log('Object ' + j)
                console.log(arr[j].name)
                console.log(arr[j].country)
                console.log(arr[j].age)

                arr[j].hobbies.forEach(function (hobbie){
                 console.log(hobbie)
                 })

                console.log("")
                console.log("")
        }    
    }
}


let B = () => {
    console.log("Objects with country india")
    console.log("")
    for (let j = 0; j < arr.length; j++) {
        if (arr[j].country == 'India') {
                console.log('Object ' + j)
                console.log(arr[j].name)
                console.log(arr[j].country)
                console.log(arr[j].age)

                arr[j].hobbies.forEach(function (hobbie){
                 console.log(hobbie)
                 })

                console.log("")
                console.log("")
        }    
    }
}

A()
B()